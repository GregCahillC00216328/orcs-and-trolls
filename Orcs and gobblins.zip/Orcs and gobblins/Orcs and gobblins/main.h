#pragma once
#include <iostream>
using namespace std;

void mainMenu();
void characterChoice();
short factionChoice = 0;